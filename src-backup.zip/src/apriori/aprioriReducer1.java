package apriori;

import java.io.IOException;
import java.util.ArrayList;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import utils.addedFunctions;

//import utils.addedFunctions;

public class aprioriReducer1 extends Reducer<Text, IntWritable, Text, LongWritable>{
	
	@Override
    protected void reduce(Text itemset, Iterable<IntWritable> values, Context context)
            throws IOException, InterruptedException{
		
		// Initial ArrayList
//     	ArrayList<String> list = new ArrayList<String>();

     	// counting the frequency
        long total = 0;
        
        for (IntWritable value : values) {
        	total += value.get();
		}
        
        String itemsetIds = itemset.toString();
        
        // getting the minimum support & maximum number of transactions
//        Double minSup = Double.parseDouble(context.getConfiguration().get("minSup"));
//        Integer numTxns = context.getConfiguration().getInt("numTxns", 2);
        
        // getting the "actual" support in respect to the maximum transaction
//        total = total / (long) numTxns;
        
        // Check if the total is greater or equal than minimum support
//        if ( addedFunctions.hasMinSupport(minSup, numTxns, total) ) 
        	context.write(new Text(itemsetIds + ","), new LongWritable(total));	
        	
        	
        /**
         * 2-itemSet
         */
        	
        	// adding all 1-itemset to the the list
//        	list.add(itemsetIds);
//        	
//        	// ArrayList to hold the final combinations
//        	ArrayList<String> getListFromComb = new ArrayList<String>();
//        	
//        	// Get the combinations
//        	getListFromComb = addedFunctions.getCombinations(list);
//        	
//        	//
//        	String words[];
//        	
//        	// Printing all the elements of the ArrayList getListFromComb
//    		for (String AString : getListFromComb) {
//    			
//    			// Very bad idea - still a solution
//    			words = AString.split("\\s");
//    			
//    			// Checking Palindrome
//    			if ( Integer.parseInt(words[0]) > Integer.parseInt(words[1]) ){
//    				// Empty string
//    				AString = "";
//    				AString += words[1];
//    				AString += " ";
//    				AString += words[0];
//    			}
//    			
//    			// 2-itemSet
//    			context.write(new Text(AString), new LongWritable(total));
//    		}

    }

}
